create view ship as
  SELECT vv.id,
    v.vesselname AS name,
    v.imo,
    v.mmsi,
    v.flag,
    yb.detailvalue AS yearbuild,
    min(sy.detailvalue) AS shipyard,
    v.length,
    vv.company_id,
    min(vv.polygon_id) AS polygon_id,
    min(vv.dock_id) AS dock_id,
    vv.start_ts,
    vv.end_ts,
    (vv.end_ts - vv.start_ts) AS c_days,
    max(dv.days) AS d_days
   FROM (((((vessels v
     LEFT JOIN vesseldetails yb ON (((yb.vesselid = v.vesselid) AND (yb.detailkey = 'Year Of Built'::text))))
     LEFT JOIN vesseldetails sy ON (((sy.vesselid = v.vesselid) AND (yb.detailkey = 'Shipyard'::text))))
     JOIN vessel_visits vv ON ((v.imo = vv.imo)))
     LEFT JOIN ( SELECT d_1.company_id,
            vv_1.id,
            vv_1.imo,
            count(*) AS docks,
            sum((vv_1.end_ts - vv_1.start_ts)) AS days,
            min(vv_1.start_ts) AS start_ts,
            max(vv_1.end_ts) AS end_ts
           FROM (dock d_1
             LEFT JOIN vessel_visits vv_1 ON ((vv_1.polygon_id = d_1.polygon_id)))
          WHERE (d_1.type <> 'COMPANY_AREA'::dock_type)
          GROUP BY d_1.company_id, vv_1.imo, vv_1.id) dv ON (((dv.company_id = vv.company_id) AND (dv.start_ts >= vv.start_ts) AND (dv.end_ts <= vv.end_ts))))
     JOIN dock d ON (((d.polygon_id = vv.polygon_id) AND (d.type = 'COMPANY_AREA'::dock_type))))
  WHERE (v.length >= (50)::numeric)
  GROUP BY vv.id, v.vesselname, v.imo, v.mmsi, v.flag, yb.detailvalue, v.length, vv.company_id, vv.start_ts, vv.end_ts;

