create view scrapping_stat as
  SELECT row_number() OVER () AS id,
    b.company_id,
    b.vessel_type,
    b.age_cat,
    count(b.age_cat) AS n
   FROM ( SELECT a.vessel_type,
            a.company_id,
                CASE
                    WHEN (a.age <= (5)::double precision) THEN '0-5'::text
                    WHEN ((a.age > (5)::double precision) AND (a.age <= (10)::double precision)) THEN '5-10'::text
                    WHEN ((a.age > (10)::double precision) AND (a.age <= (15)::double precision)) THEN '10-15'::text
                    WHEN ((a.age > (15)::double precision) AND (a.age <= (20)::double precision)) THEN '15-20'::text
                    WHEN ((a.age > (20)::double precision) AND (a.age <= (25)::double precision)) THEN '20-25'::text
                    WHEN ((a.age > (25)::double precision) AND (a.age <= (30)::double precision)) THEN '25-30'::text
                    WHEN (a.age > (30)::double precision) THEN '>30'::text
                    ELSE NULL::text
                END AS age_cat
           FROM ( SELECT DISTINCT ON (vd.imo) upper(vd.vessel_type) AS vessel_type,
                    vv.company_id,
                    (date_part('year'::text, vv.end_ts) - (vd.vessel_yob)::double precision) AS age
                   FROM (vessel_visits vv
                     JOIN ((( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                            (vesseldetails.detailvalue)::integer AS imo
                           FROM vesseldetails
                          WHERE (vesseldetails.detailkey = 'Imo'::text)) id1
                     JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                            (vesseldetails.detailvalue)::integer AS vessel_yob
                           FROM vesseldetails
                          WHERE (vesseldetails.detailkey = 'Year Of Built'::text)) det1 ON ((det1.vesselid = id1.vesselid)))
                     JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                            vesseldetails.detailvalue AS vessel_type
                           FROM vesseldetails
                          WHERE (vesseldetails.detailkey = 'Vessel Type'::text)) det2 ON ((det2.vesselid = id1.vesselid))) vd(vesselid, imo, vesselid_1, vessel_yob, vesselid_2, vessel_type) ON ((vv.imo = vd.imo)))
                  WHERE (vv.status = 'scrapped'::text)
                  GROUP BY vd.imo, vd.vessel_type, vv.company_id, (date_part('year'::text, vv.end_ts) - (vd.vessel_yob)::double precision)) a) b
  GROUP BY b.company_id, b.vessel_type, b.age_cat
  ORDER BY b.company_id, (count(b.age_cat)) DESC;

