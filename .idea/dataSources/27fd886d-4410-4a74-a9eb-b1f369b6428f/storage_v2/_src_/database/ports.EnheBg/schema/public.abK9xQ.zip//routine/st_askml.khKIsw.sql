create function st_askml(version integer, geog geography, maxdecimaldigits integer DEFAULT 15, nprefix text DEFAULT NULL::text)
  returns text
immutable
parallel safe
language sql
as $$
SELECT public._ST_AsKML($1, $2, $3, $4)
$$;

