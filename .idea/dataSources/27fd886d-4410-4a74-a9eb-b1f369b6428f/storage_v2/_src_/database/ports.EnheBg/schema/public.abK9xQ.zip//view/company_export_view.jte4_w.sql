create view company_export_view as
  SELECT c.id AS company_id,
    p.id AS polygon_id,
    p.area,
    (d.type)::text AS type,
    sc.service_id,
    c.create_time AS com_create_time,
    c.update_time AS com_update_time,
    p.create_time AS poly_create_time,
    p.update_time AS poly_update_time
   FROM (((company c
     JOIN dock d ON ((c.id = d.company_id)))
     JOIN polygon p ON ((p.id = d.polygon_id)))
     LEFT JOIN service_company sc ON ((c.id = sc.company_id)))
  WHERE ((c.deleted IS FALSE) AND (d.deleted IS FALSE) AND (p.deleted IS FALSE) AND (c.visible IS TRUE) AND (p.area IS NOT NULL) AND (sc.service_id = ANY (ARRAY[1, 2, 3])));

