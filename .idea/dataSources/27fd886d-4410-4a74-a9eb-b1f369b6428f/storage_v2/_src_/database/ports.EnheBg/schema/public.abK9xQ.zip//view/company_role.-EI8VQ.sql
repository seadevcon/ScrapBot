create view company_role as
  SELECT DISTINCT ON (id8.id) id8.id AS cid,
    id1.manager,
    id2.man_agent,
    id3.ism_manager,
    id4.operator,
    id5.owner,
    id6.man_owner,
    id7.tech_manager
   FROM (((((((( SELECT company.id
           FROM company
          WHERE (company.type_id = 5)) id8
     LEFT JOIN ( SELECT DISTINCT ON (company_vessel.cid) company_vessel.cid,
            count(company_vessel.vid) AS manager
           FROM company_vessel
          WHERE (company_vessel.company_role = 'Manager'::text)
          GROUP BY company_vessel.cid) id1 ON ((id1.cid = id8.id)))
     LEFT JOIN ( SELECT DISTINCT ON (company_vessel.cid) company_vessel.cid,
            count(company_vessel.vid) AS man_agent
           FROM company_vessel
          WHERE (company_vessel.company_role = 'Man Agent'::text)
          GROUP BY company_vessel.cid) id2 ON ((id2.cid = id8.id)))
     LEFT JOIN ( SELECT DISTINCT ON (company_vessel.cid) company_vessel.cid,
            count(company_vessel.vid) AS ism_manager
           FROM company_vessel
          WHERE (company_vessel.company_role = 'Ism Manager'::text)
          GROUP BY company_vessel.cid) id3 ON ((id3.cid = id8.id)))
     LEFT JOIN ( SELECT DISTINCT ON (company_vessel.cid) company_vessel.cid,
            count(company_vessel.vid) AS operator
           FROM company_vessel
          WHERE (company_vessel.company_role = 'Operator'::text)
          GROUP BY company_vessel.cid) id4 ON ((id4.cid = id8.id)))
     LEFT JOIN ( SELECT DISTINCT ON (company_vessel.cid) company_vessel.cid,
            count(company_vessel.vid) AS owner
           FROM company_vessel
          WHERE (company_vessel.company_role = 'Owner'::text)
          GROUP BY company_vessel.cid) id5 ON ((id5.cid = id8.id)))
     LEFT JOIN ( SELECT DISTINCT ON (company_vessel.cid) company_vessel.cid,
            count(company_vessel.vid) AS man_owner
           FROM company_vessel
          WHERE (company_vessel.company_role = 'Man Owner'::text)
          GROUP BY company_vessel.cid) id6 ON ((id6.cid = id8.id)))
     LEFT JOIN ( SELECT DISTINCT ON (company_vessel.cid) company_vessel.cid,
            count(company_vessel.vid) AS tech_manager
           FROM company_vessel
          WHERE (company_vessel.company_role = 'Tech Man'::text)
          GROUP BY company_vessel.cid) id7 ON ((id7.cid = id8.id)));

