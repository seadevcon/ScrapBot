create function st_longestline(geom1 geometry, geom2 geometry)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_LongestLine(public.ST_ConvexHull($1), public.ST_ConvexHull($2))
$$;

