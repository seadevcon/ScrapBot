create view weather_statistics as
  SELECT row_number() OVER () AS id,
    a.company_id,
    a.month,
    round(a.tmp2m_max, 1) AS tmp_max,
    round(a.tmp2m_mean, 1) AS tmp_mean,
    round(a.tmp2m_min, 1) AS tmp_min,
    round((((a.tmp2m_max * (9)::numeric) / (5)::numeric) + (32)::numeric), 1) AS tmp_max_f,
    round((((a.tmp2m_mean * (9)::numeric) / (5)::numeric) + (32)::numeric), 1) AS tmp_mean_f,
    round((((a.tmp2m_min * (9)::numeric) / (5)::numeric) + (32)::numeric), 1) AS tmp_min_f,
    floor(a.precip_sum_month) AS precip_tot_mm,
    round((a.wind_speed_mean * 3.6), 1) AS wind_speed_kmph,
    round((a.wind_speed_mean * 1.94384), 1) AS wind_speed_knots,
    a.wind_dir_sector AS wind_dir,
    round(a.wavehgt_mean, 1) AS wavehgt_mean,
    round(a.wavehgt_max, 1) AS wavehgt_max,
    round(a.salinity_mean, 2) AS salinity_psu
   FROM (weather_stat a
     RIGHT JOIN company c ON ((a.company_id = c.id)))
  WHERE ((c.deleted IS FALSE) AND (c.visible IS TRUE) AND (a.show_in_frontend IS TRUE));

