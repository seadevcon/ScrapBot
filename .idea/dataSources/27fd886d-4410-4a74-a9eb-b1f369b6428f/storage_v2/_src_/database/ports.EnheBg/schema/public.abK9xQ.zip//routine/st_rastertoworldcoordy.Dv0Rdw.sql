create function st_rastertoworldcoordy(rast raster, yr integer)
  returns double precision
immutable
strict
parallel safe
language sql
as $$
SELECT latitude FROM public._ST_rastertoworldcoord($1, NULL, $2)
$$;

