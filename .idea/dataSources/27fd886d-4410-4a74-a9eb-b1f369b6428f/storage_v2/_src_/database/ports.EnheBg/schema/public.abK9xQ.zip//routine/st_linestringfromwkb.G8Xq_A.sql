create function st_linestringfromwkb(bytea, integer)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN public.ST_GeomFromWKB($1, $2)
	ELSE NULL END

$$;

