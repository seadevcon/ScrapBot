create view company_newbuilds_brl as
  SELECT DISTINCT ON (b.identification_brlshipid) row_number() OVER () AS id,
    b.identification_brlshipid,
    st.buildcompany_id AS company_id,
    b.identification_imo AS vessel_imo,
    b.identification_vesselname AS vessel_name,
    nh.vessel_name AS vessel_name_shipdb,
    b.classification_vesseltype AS vessel_type,
    b.classification_vesselsubtype AS vessel_subtype,
    b.dimension_lengthoa AS vessel_length,
    b.dimension_draft AS vessel_draft,
    b.dimension_beamextreme AS vessel_beamextreme,
    b.power_totalmainkw AS vessel_totalkw,
    b.tonnage_dwt AS vessel_dwt,
    b.date_contractdate AS vessel_datecontract,
    b.date_deliverydate AS vessel_datedelivery,
    b.mainengines_engineenginemodel AS engine_model,
    b.mainengines_enginecompanyenginedesigner AS engine_designer,
    b.mainengines_enginecompanyenginebuilder AS engine_builder,
    b.mainengines_enginetotalkw AS engine_totalkw,
    b.company_groupowner,
    b.company_beneficialowner AS buyer_name,
    b.company_beneficialownercountry AS buyer_country,
    st.status AS vessel_status,
    cn.a2 AS buyer_country_a2,
    st.first_ts,
    st.area,
    st.dist,
    st.dist_last6m,
    nh.vessel_yob,
    nh.contract_date,
    nh.vessel_delivery_date,
    nh.vessel_delivery_date1,
    nh.vessel_launch_date,
    nh.vessel_survey1_date,
    nh.vessel_survey1_date_next,
    nh.vessel_survey2_date,
    nh.vessel_survey2_date_next
   FROM (((brl_newbuilds_status st
     JOIN brl_newbuilds b ON ((b.identification_imo = st.imo)))
     LEFT JOIN country cn ON ((b.company_beneficialownercountryiso = (cn.a3)::text)))
     LEFT JOIN newbuilds_historic nh ON ((nh.vessel_imo = b.identification_imo)))
  WHERE ((b.deleted IS FALSE) AND (st.status IS NOT NULL))
  ORDER BY b.identification_brlshipid, b.identification_imo;

