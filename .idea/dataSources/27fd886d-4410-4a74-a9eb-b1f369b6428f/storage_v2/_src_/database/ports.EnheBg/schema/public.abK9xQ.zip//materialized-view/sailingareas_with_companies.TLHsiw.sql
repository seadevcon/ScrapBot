CREATE MATERIALIZED VIEW sailingareas_with_companies AS SELECT row_number() OVER () AS id,
    c.id AS company_id,
    g.id AS sailingarea_id,
    g.name
   FROM geopoly g,
    company c
  WHERE (st_intersects(c.location, g.area) AND (g.type = 'sailingarea'::text) AND (c.visible = true) AND (c.deleted = false));

create index sailingareas_with_companies_company_id_idx
  on sailingareas_with_companies (company_id);

