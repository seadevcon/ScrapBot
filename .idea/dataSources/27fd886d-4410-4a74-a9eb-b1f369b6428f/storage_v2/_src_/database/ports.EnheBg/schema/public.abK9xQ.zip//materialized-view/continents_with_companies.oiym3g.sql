CREATE MATERIALIZED VIEW continents_with_companies AS SELECT row_number() OVER () AS id,
    c.id AS company_id,
    g.subregion AS name,
    g.id AS geopoly_id
   FROM geopoly g,
    company c
  WHERE (st_intersects(c.location, g.area) AND (g.subregion IS NOT NULL) AND (c.visible = true) AND (c.deleted = false));

