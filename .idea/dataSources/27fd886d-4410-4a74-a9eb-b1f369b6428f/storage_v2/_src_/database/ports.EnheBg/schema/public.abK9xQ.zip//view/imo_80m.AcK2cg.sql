create view imo_80m as
  SELECT DISTINCT a.imo
   FROM (( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
            vesseldetails.detailvalue AS imo
           FROM vesseldetails
          WHERE (vesseldetails.detailkey = 'Imo'::text)) a
     JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
            vesseldetails.detailvalue AS lengthbp
           FROM vesseldetails
          WHERE (vesseldetails.detailkey = 'Length Bp'::text)) b ON ((a.vesselid = b.vesselid)))
  WHERE ((b.lengthbp)::numeric > (80)::numeric);

