create function st_asbinary(geography, text)
  returns bytea
immutable
strict
parallel safe
language sql
as $$
SELECT public.ST_AsBinary($1::public.geometry, $2);
$$;

