create view vessels_details as
  SELECT DISTINCT ON (a.imo) row_number() OVER () AS id,
    a.vesselid,
    a.imo,
    a.vessel_name,
    a.vessel_type,
    a.vessel_dwt,
    a.vessel_length,
    a.vessel_beamextreme,
    a.vessel_draft,
    a.builder_name,
    a.builder_country,
    a.vessel_yob,
    a.vessel_delivery_date,
    a.vessel_delivery_date1,
    a.vessel_launch_date,
    a.vessel_flag,
    a.vessel_status,
    a.vessel_survey1_date,
    a.vessel_survey2_date,
    a.vessel_survey1_date_next,
    a.vessel_survey2_date_next,
    a.classed_by_1,
    a.classed_by_1_status,
    a.classed_by_1_reason,
    a.classed_by_2,
    a.classed_by_2_status,
    a.classed_by_2_reason,
    a.survey1_society,
    a.survey2_society,
    a.owner_name,
    a.owner_country,
    a.owner_address,
    a.owner_email,
    a.owner_web,
    a.owner_phone,
    a.owner_fax,
    a.manager_name,
    a.manager_country,
    a.manager_address,
    a.manager_email,
    a.manager_web,
    a.manager_phone,
    a.manager_fax,
    a.engine_model,
    a.engine_totalkw,
    a.engine_builder
   FROM ( SELECT DISTINCT ON (id1.vesselid) id1.vesselid,
            (id1.imo)::integer AS imo,
            id2.vessel_name,
            cl1.vessel_type,
            (replace(cap1.vessel_dwt, ','::text, '.'::text))::numeric AS vessel_dwt,
            (replace(dim1.vessel_length, ','::text, '.'::text))::numeric AS vessel_length,
            (replace(dim2.vessel_beamextreme, ','::text, '.'::text))::numeric AS vessel_beamextreme,
            (replace(dim3.vessel_draft, ','::text, '.'::text))::numeric AS vessel_draft,
            build1.builder_name,
            build2.builder_country,
            (det1.vessel_yob)::integer AS vessel_yob,
            det2.vessel_delivery_date,
            det3.vessel_delivery_date1,
            det4.vessel_launch_date,
            det5.vessel_flag,
            stat1.vessel_status,
            stat2.vessel_survey1_date,
            stat3.vessel_survey2_date,
            stat4.vessel_survey1_date_next,
            stat5.vessel_survey2_date_next,
            stat6.classed_by_1,
            stat7.classed_by_1_status,
            stat8.classed_by_1_reason,
            stat9.classed_by_2,
            stat10.classed_by_2_status,
            stat11.classed_by_2_reason,
            stat12.survey1_society,
            stat13.survey2_society,
            own1.owner_name,
            own2.owner_country,
            own3.owner_address,
            own4.owner_email,
            own5.owner_web,
            own6.owner_phone,
            own7.owner_fax,
            man1.manager_name,
            man2.manager_country,
            man3.manager_address,
            man4.manager_email,
            man5.manager_web,
            man6.manager_phone,
            man7.manager_fax,
            eng1.engine_model,
            (replace(eng2.engine_totalkw, ','::text, '.'::text))::numeric AS engine_totalkw,
            eng3.engine_builder
           FROM (((((((((((((((((((((((((((((((((((((((((((( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS imo
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Imo'::text)) id1
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_name
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Vessel Name'::text)) id2 ON ((id2.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_type
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Vessel Type'::text)) cl1 ON ((cl1.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_dwt
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Deadweight'::text)) cap1 ON ((cap1.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_length
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Length Overall'::text)) dim1 ON ((dim1.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_beamextreme
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Breadth Extreme'::text)) dim2 ON ((dim2.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_draft
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Draught'::text)) dim3 ON ((dim3.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS builder_name
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Builder'::text)) build1 ON ((build1.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS builder_country
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Country Place Of Build'::text)) build2 ON ((build2.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_yob
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Year Of Built'::text)) det1 ON ((det1.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_delivery_date
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Completion Date'::text)) det2 ON ((det2.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_delivery_date1
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Status Date Normalized'::text)) det3 ON ((det3.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_launch_date
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Launch Date'::text)) det4 ON ((det4.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_flag
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Flag'::text)) det5 ON ((det5.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_status
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Status Of Ship Standardized'::text)) stat1 ON ((stat1.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_survey1_date
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Survey 1 Date'::text)) stat2 ON ((stat2.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_survey2_date
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Survey 2 Date'::text)) stat3 ON ((stat3.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_survey1_date_next
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Survey 1 Next Date'::text)) stat4 ON ((stat4.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS vessel_survey2_date_next
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Survey 2 Next Date'::text)) stat5 ON ((stat5.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS classed_by_1
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Classed By 1'::text)) stat6 ON ((stat6.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS classed_by_1_status
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Classed By 1 Status'::text)) stat7 ON ((stat7.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS classed_by_1_reason
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Classed By 1 Reason'::text)) stat8 ON ((stat8.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS classed_by_2
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Classed By 2'::text)) stat9 ON ((stat9.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS classed_by_2_status
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Classed By 2 Status'::text)) stat10 ON ((stat10.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS classed_by_2_reason
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Classed By 2 Reason'::text)) stat11 ON ((stat11.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS survey1_society
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Survey 1'::text)) stat12 ON ((stat12.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS survey2_society
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Survey 2'::text)) stat13 ON ((stat13.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS owner_name
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Owner Name'::text)) own1 ON ((own1.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS owner_country
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Owner Location'::text)) own2 ON ((own2.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS owner_address
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Owner Address'::text)) own3 ON ((own3.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS owner_email
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Owner Email'::text)) own4 ON ((own4.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS owner_web
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Owner Website'::text)) own5 ON ((own5.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS owner_phone
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Owner Phone'::text)) own6 ON ((own6.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS owner_fax
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Owner Fax'::text)) own7 ON ((own7.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS manager_name
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Manager Name'::text)) man1 ON ((man1.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS manager_country
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Manager Location'::text)) man2 ON ((man2.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS manager_address
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Manager Address'::text)) man3 ON ((man3.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS manager_email
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Manager Email'::text)) man4 ON ((man4.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS manager_web
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Manager Website'::text)) man5 ON ((man5.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS manager_phone
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Manager Phone'::text)) man6 ON ((man6.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS manager_fax
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Manager Fax'::text)) man7 ON ((man7.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS engine_model
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Main Engine'::text)) eng1 ON ((eng1.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS engine_totalkw
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Main Engine Kw'::text)) eng2 ON ((eng2.vesselid = id1.vesselid)))
             LEFT JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
                    vesseldetails.detailvalue AS engine_builder
                   FROM vesseldetails
                  WHERE (vesseldetails.detailkey = 'Engine Builder'::text)) eng3 ON ((eng3.vesselid = id1.vesselid)))) a;

