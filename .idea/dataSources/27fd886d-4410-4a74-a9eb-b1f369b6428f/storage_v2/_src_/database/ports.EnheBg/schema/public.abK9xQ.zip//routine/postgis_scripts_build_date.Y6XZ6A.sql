create function postgis_scripts_build_date()
  returns text
immutable
language sql
as $$
SELECT '2016-09-28 11:36:27'::text AS version
$$;

