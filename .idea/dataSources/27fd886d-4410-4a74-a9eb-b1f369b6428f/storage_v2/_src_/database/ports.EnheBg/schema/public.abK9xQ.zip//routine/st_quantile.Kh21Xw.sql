create function st_quantile(rast raster, quantile double precision)
  returns double precision
immutable
strict
parallel safe
language sql
as $$
SELECT ( public._ST_quantile($1, 1, TRUE, 1, ARRAY[$2]::double precision[])).value
$$;

