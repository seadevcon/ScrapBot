create function postgis_scripts_installed()
  returns text
immutable
language sql
as $$
SELECT '2.3.0'::text || ' r' || 15146::text AS version
$$;

