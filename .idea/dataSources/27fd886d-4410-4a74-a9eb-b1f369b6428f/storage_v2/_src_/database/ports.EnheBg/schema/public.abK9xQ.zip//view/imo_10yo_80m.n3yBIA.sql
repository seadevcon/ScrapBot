create view imo_10yo_80m as
  SELECT DISTINCT a.imo
   FROM ((( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
            vesseldetails.detailvalue AS imo
           FROM vesseldetails
          WHERE (vesseldetails.detailkey = 'Imo'::text)) a
     JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
            vesseldetails.detailvalue AS lengthbp
           FROM vesseldetails
          WHERE (vesseldetails.detailkey = 'Length Bp'::text)) b ON ((a.vesselid = b.vesselid)))
     JOIN ( SELECT DISTINCT ON (vesseldetails.vesselid) vesseldetails.vesselid,
            vesseldetails.detailvalue AS yob
           FROM vesseldetails
          WHERE (vesseldetails.detailkey = 'Year Of Built'::text)) c ON ((a.vesselid = c.vesselid)))
  WHERE ((((c.yob)::integer)::double precision <= (date_part('year'::text, now()) - (10)::double precision)) AND ((b.lengthbp)::numeric > (80)::numeric));

