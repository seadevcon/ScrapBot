create function dropgeometrytable(table_name character varying)
  returns text
strict
language sql
as $$
SELECT DropGeometryTable('','',$1)
$$;

