create view company_view as
  SELECT DISTINCT c.id,
    max((c.name)::text) AS name,
    max((cc.name)::text) AS country,
    count(t.id) AS tug_count,
    max(c.status) AS status,
    max(c.create_time) AS create_time,
    c.group_name,
    c.web AS website,
    max(poly.number_of_polygons) AS number_polygons,
    max(vv.visits) AS ships_in_polygons,
    c.approved,
    c.visible,
    max(c.update_time) AS last_updated,
    max((ct.name)::text) AS company_type,
    max((ad.city)::text) AS city,
    max(c.port_id) AS port_id,
    max(poly.number_of_areas) AS company_areas,
    st_astext(st_transform(c.location, 4326)) AS latlng,
    c.max_length,
    c.max_width,
    count(i.id) AS number_images,
    max(c.max_depth) AS max_depth,
    c.facebook_link,
    c.wikipedia_link,
    c.main_email,
    c.inconsistent,
    cvv.number_vessels,
    max(bl.number_orders) AS number_orders,
    max(nw.number_newbuilds_historic) AS number_newbuilds_historic,
    c.linkedin_link
   FROM ((((((((((company c
     LEFT JOIN images i ON ((c.id = i.companyid)))
     LEFT JOIN tug_old t ON ((c.id = t.company_id)))
     LEFT JOIN address ad ON ((c.address_id = ad.id)))
     LEFT JOIN country cc ON ((ad.country_id = cc.id)))
     LEFT JOIN company_type ct ON ((ct.id = c.type_id)))
     LEFT JOIN ( SELECT d.company_id,
            sum(
                CASE d.type
                    WHEN 'COMPANY_AREA'::dock_type THEN 0
                    ELSE 1
                END) AS number_of_polygons,
            sum(
                CASE d.type
                    WHEN 'COMPANY_AREA'::dock_type THEN 1
                    ELSE 0
                END) AS number_of_areas,
            sum(
                CASE util.vessels_number
                    WHEN NULL::integer THEN 0
                    ELSE util.vessels_number
                END) AS ships_in_polygon
           FROM ((dock d
             LEFT JOIN polygon p ON ((d.polygon_id = p.id)))
             LEFT JOIN shipyard_utilisation_old util ON ((util.polygon_id = p.id)))
          WHERE ((d.polygon_id IS NOT NULL) AND (d.deleted = false) AND (p.deleted = false))
          GROUP BY d.company_id) poly ON ((poly.company_id = c.id)))
     LEFT JOIN ( SELECT vv_1.company_id,
            count(*) AS visits,
            count(DISTINCT d.id) AS company_areas
           FROM (((vessel_visits vv_1
             JOIN polygon p ON ((p.id = vv_1.polygon_id)))
             JOIN dock d ON (((d.polygon_id = p.id) AND ((d.type = 'COMPANY_AREA'::dock_type) OR (d.type IS NULL)))))
             JOIN vessels v ON (((vv_1.imo = v.imo) AND (v.length >= (50)::numeric))))
          WHERE ((d.deleted = false) AND (p.deleted = false))
          GROUP BY vv_1.company_id) vv ON ((vv.company_id = c.id)))
     LEFT JOIN ( SELECT count(*) AS number_vessels,
            company_vessel.cid
           FROM company_vessel
          GROUP BY company_vessel.cid) cvv ON ((cvv.cid = c.id)))
     LEFT JOIN ( SELECT count(*) AS number_orders,
            brl_newbuilds.company_idsbuilderid
           FROM brl_newbuilds
          GROUP BY brl_newbuilds.company_idsbuilderid) bl ON ((c.brl_company_builder_id = bl.company_idsbuilderid)))
     LEFT JOIN ( SELECT count(*) AS number_newbuilds_historic,
            newbuilds_historic.builder_id
           FROM newbuilds_historic
          GROUP BY newbuilds_historic.builder_id) nw ON ((c.id = nw.builder_id)))
  WHERE (c.deleted = false)
  GROUP BY c.id, c.name, c.group_name, c.web, c.approved, c.visible, c.location, c.max_length, c.max_width, c.facebook_link, c.wikipedia_link, c.inconsistent, cvv.number_vessels, c.linkedin_link;

