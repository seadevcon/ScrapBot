create view company_not_matched as
  SELECT cd.id,
    cd.name,
    cd.main_email,
    cd.second_email,
    cd.docking_request_email,
    cd.phone,
    cd.country_name
   FROM ( SELECT c.id,
            c.name,
            c.main_email,
            c.second_email,
            c.docking_request_email,
            a.phone,
            cc.name AS country_name
           FROM ((company c
             LEFT JOIN country cc ON ((c.country_id = cc.id)))
             LEFT JOIN address a ON ((c.address_id = a.id)))
          WHERE ((c.type_id = 3) AND (c.deleted = false) AND (NOT (c.id IN ( SELECT user_company.company_id
                   FROM user_company))))) cd;

